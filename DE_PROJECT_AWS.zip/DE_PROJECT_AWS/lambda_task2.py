import json
import boto3
import time

# Initialize boto3 clients for Glue and Lambda
glue_client = boto3.client('glue')
lambda_client = boto3.client('lambda')

# Update Lambda function configuration (e.g., set timeout to 500 seconds)
lambda_client.update_function_configuration(
    FunctionName='s3-etl-task2',
    Timeout=500  # Timeout in seconds
)

def lambda_handler(event, context):
    # Print the incoming event for debugging purposes
    print(f"Received event: {json.dumps(event)}")

    # Define names for Glue Crawler and ETL Job
    glue_crawler_name = "cleaned"
    glue_job_name = "Untitled"  # Replace with your Glue ETL job name

    try:
        esponse = glue_client.get_crawler(Name=glue_crawler_name)
        crawler_status = esponse['Crawler']['State']
        print(f"Crawler status: {crawler_status}")
        # Step 1: Start the Glue Crawler
        print(f"Starting Glue crawler: {glue_crawler_name}")
        glue_client.start_crawler(Name=glue_crawler_name)
        
        # Step 2: Poll for Glue Crawler status
        while True:
            # Get the status of the Glue Crawler
            response = glue_client.get_crawler(Name=glue_crawler_name)
            crawler_status = response['Crawler']['State']
            print(f"Crawler status: {crawler_status}")

            # Check if the crawler is finished (either 'READY', 'STOPPING', or 'STOPPED')
            if crawler_status in ['READY', 'STOPPING', 'STOPPED']:
                print(f"Crawler finished with status: {crawler_status}")
                break  # Exit the loop if crawler has finished
            else:
                print("Crawler still running. Waiting for 60 seconds before checking again...")
                time.sleep(60)  # Wait 60 seconds before checking the status again

        # Step 3: Start the Glue ETL Job after the crawler has completed
        print(f"Starting Glue ETL job: {glue_job_name}")
        glue_client.start_job_run(JobName=glue_job_name)

        return {
            'statusCode': 200,
            'body': json.dumps('Crawler completed and ETL job started successfully.')
        }
        
    except Exception as e:
        # Print the error and return a response with the error message
        print(f"Error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }
