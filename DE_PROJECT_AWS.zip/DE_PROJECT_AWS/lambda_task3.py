import boto3
import os
import csv
import json
import tempfile
from botocore.exceptions import ClientError

lambda_client = boto3.client('lambda')

# Update Lambda function configuration (e.g., set timeout to 60 seconds)
lambda_client.update_function_configuration(
    FunctionName='s3-glue',
    Timeout=200  # Timeout in seconds
)

# Initialize AWS clients
s3_client = boto3.client('s3')
glue_client = boto3.client('glue')

# Define your Glue Database and Table name
DATABASE_NAME = 'NYC_INSPECTION_DB'
TABLE_NAME = 'INSPECTION_TABLE'

# S3 bucket and path for the incoming files
S3_BUCKET = 'de-cloud-project'
S3_PREFIX = 'transformed/'

def lambda_handler(event, context):
    # Get the S3 bucket and object key from the event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    object_key = event['Records'][0]['s3']['object']['key']
    
    # Check if the file is within the 'transformed/' prefix
    if not object_key.startswith(S3_PREFIX):
        return {
            'statusCode': 400,
            'body': json.dumps('File is not in the expected directory.')
        }
    
    # Create a Glue Database if it doesn't exist
    if not check_glue_database_exists(DATABASE_NAME):
        create_glue_database(DATABASE_NAME)
    
    # Drop the existing table and create a new one
    drop_glue_table_if_exists(DATABASE_NAME, TABLE_NAME)
    create_glue_table(DATABASE_NAME, TABLE_NAME)

    # Process the CSV file from S3 and insert data into Glue
    process_csv_and_insert_data(bucket_name, object_key)

    bucket = 'de-cloud-project'

    # Define source and archive prefixes
    operations = [
        {'source_prefix': 'input/', 'archive_prefix': 'input-archived/'}
        #,{'source_prefix': 'cleaned/', 'archive_prefix': 'cleaned-archived/'}
    ]

    timeout_buffer = context.get_remaining_time_in_millis() / 1000 - 1
    # Perform file movement for each folder
    for op in operations:
        move_files_to_archive(bucket, op['source_prefix'], op['archive_prefix'], max_files=1, timeout_buffer=timeout_buffer)

    return {
        'statusCode': 200,
        'body': json.dumps(f'Successfully processed file {object_key}')
    }


def move_files_to_archive(bucket, source_prefix, archive_prefix, max_files=None, timeout_buffer=None):
    """Move files from a source directory to an archive directory in the same bucket."""
    print(f"Moving files from {source_prefix} to {archive_prefix} in bucket {bucket}")
    paginator = s3_client.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=bucket, Prefix=source_prefix)

    file_count = 0
    for page in page_iterator:
        if 'Contents' not in page:
            continue
        for file in page['Contents']:
            key = file['Key']
            if key.endswith('/'):
                continue  # Skip directories
            archive_key = f"{archive_prefix}{key.split('/')[-1]}"
            print(f"Moving {key} to {archive_key}")
            s3_client.copy_object(
                Bucket=bucket,
                CopySource={'Bucket': bucket, 'Key': key},
                Key=archive_key
            )
            s3_client.delete_object(Bucket=bucket, Key=key)
            print(f"Moved and deleted file: {key}")
            
            file_count += 1
            if max_files and file_count >= max_files:
                print(f"Moved {max_files} files. Stopping.")
                return  # Exit the function after moving 'max_files' files


def check_glue_database_exists(database_name):
    """Check if the Glue database exists."""
    try:
        glue_client.get_database(Name=database_name)
        return True
    except glue_client.exceptions.EntityNotFoundException:
        return False

def create_glue_database(database_name):
    """Create a Glue database if it does not exist."""
    try:
        glue_client.create_database(
            DatabaseInput={
                'Name': database_name,
                'Description': 'Database for storing CSV data from S3'
            }
        )
        print(f"Created Glue database: {database_name}")
    except ClientError as e:
        print(f"Error creating Glue database: {e}")
        raise e


def drop_glue_table_if_exists(database_name, table_name):
    """Drop the Glue table if it exists."""
    try:
        glue_client.get_table(DatabaseName=database_name, Name=table_name)
        glue_client.delete_table(DatabaseName=database_name, Name=table_name)
        print(f"Dropped existing Glue table: {table_name}")
    except glue_client.exceptions.EntityNotFoundException:
        print(f"Glue table {table_name} does not exist. Skipping drop.")
    except ClientError as e:
        print(f"Error dropping Glue table: {e}")
        raise e

def create_glue_table(database_name, table_name):
    """Create a Glue table, dropping any existing one first."""
    try:
        glue_client.create_table(
            DatabaseName=database_name,
            TableInput={
                'Name': table_name,
                'StorageDescriptor': {
                    'Columns': [
                        {'Name': 'camis', 'Type': 'int'},
                        {'Name': 'dba', 'Type': 'string'},
                        {'Name': 'boro', 'Type': 'string'},
                        {'Name': 'building', 'Type': 'string'},
                        {'Name': 'street', 'Type': 'string'},
                        {'Name': 'zipcode', 'Type': 'string'},
                        {'Name': 'phone', 'Type': 'string'},
                        {'Name': 'cuisine description', 'Type': 'string'},
                        {'Name': 'inspection date', 'Type': 'string'},
                        {'Name': 'action', 'Type': 'string'},
                        {'Name': 'violation code', 'Type': 'string'},
                        {'Name': 'violation description', 'Type': 'string'},
                        {'Name': 'critical flag', 'Type': 'string'},
                        {'Name': 'score', 'Type': 'string'},
                        {'Name': 'grade', 'Type': 'string'},
                        {'Name': 'grade date', 'Type': 'string'},
                        {'Name': 'record date', 'Type': 'string'},
                        {'Name': 'inspection type', 'Type': 'string'},
                        {'Name': 'latitude', 'Type': 'string'},
                        {'Name': 'longitude', 'Type': 'string'},
                        {'Name': 'community board', 'Type': 'string'},
                        {'Name': 'council district', 'Type': 'string'},
                        {'Name': 'census tract', 'Type': 'string'},
                        {'Name': 'bin', 'Type': 'string'},
                        {'Name': 'bbl', 'Type': 'string'},
                        {'Name': 'nta', 'Type': 'string'},
                        {'Name': 'grade day', 'Type': 'string'},
                        {'Name': 'inspection day', 'Type': 'string'},
                        {'Name': 'difference', 'Type': 'string'}
                    ],
                    'Location': f's3://{S3_BUCKET}/{S3_PREFIX}',  # Location where the files are stored
                    'InputFormat': 'org.apache.hadoop.mapred.TextInputFormat',
                    'OutputFormat': 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat',
                    'SerdeInfo': {
                        'Name': 'csv-serde',
                        'SerializationLibrary': 'org.apache.hadoop.hive.serde2.OpenCSVSerde',
                        'Parameters': {
                            'separatorChar': ',',
                            'quoteChar': '"'
                        }
                    }
                },
                'TableType': 'EXTERNAL_TABLE'
            }
        )
        print(f"Created Glue table: {table_name}")
    except ClientError as e:
        print(f"Error creating Glue table: {e}")
        raise e

def process_csv_and_insert_data(bucket_name, object_key):
    """Process CSV file and insert data into Glue."""
    # Download the CSV file from S3 to a temporary location
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file_path = tmp_file.name
        s3_client.download_file(bucket_name, object_key, tmp_file_path)
        print(f"Downloaded file {object_key} to {tmp_file_path}")
        
        # Read the CSV and process each row (you can add more logic here if needed)
        with open(tmp_file_path, mode='r', newline='', encoding='utf-8') as csv_file:
            csv_reader = csv.DictReader(csv_file)
            # Assuming the columns match what the Glue table expects, insert the data
            i=0
            for row in csv_reader:
                # Here you would add logic to insert data into Glue using a Glue crawler
                # Or use AWS Glue ETL jobs to process the data and load it into the table.
                print(f"Inserting row: {row}")
                break
                # Example: Print the row or insert logic goes here

        # Clean up the temporary file
        os.remove(tmp_file_path)
        print(f"Deleted temporary file {tmp_file_path}")
