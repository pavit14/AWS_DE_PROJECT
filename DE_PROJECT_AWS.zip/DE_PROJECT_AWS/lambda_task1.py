import json
import boto3
import logging
import time

# Initialize boto3 clients
glue_client = boto3.client('glue')
databrew_client = boto3.client('databrew')
lambda_client = boto3.client('lambda')
s3_client = boto3.client('s3')

# Update Lambda function configuration (e.g., set timeout to 200 seconds)
lambda_client.update_function_configuration(
    FunctionName='s3-databrew-task1',
    Timeout=500  # Timeout in seconds
)

def lambda_handler(event, context):
    # Log the event (S3 event)
    logging.info(f"Received event: {json.dumps(event)}")
    
    # Extract file information from the event
    s3_bucket = event['Records'][0]['s3']['bucket']['name']
    s3_key = event['Records'][0]['s3']['object']['key']
    
    # Name of the Glue Crawler and DataBrew Job
    glue_crawler_name = "new-inspection"
    databrew_job_name = "profile"
    
    # Archive settings
    bucket = 'de-cloud-project'
    operations = [
        {'source_prefix': 'transformed/', 'archive_prefix': 'transformed-archived/'},
        {'source_prefix': 'cleaned/', 'archive_prefix': 'cleaned-archived/'}
    ]
    
    # Timeout buffer for file movement
    timeout_buffer = context.get_remaining_time_in_millis() / 1000 - 1
    
    try:
        # Step 1: Start Glue Crawler
        logging.info(f"Starting Glue crawler: {glue_crawler_name}")
        print(f"Starting Glue crawler: {glue_crawler_name}")
        glue_client.start_crawler(Name=glue_crawler_name)

        # Step 2: Poll for the Glue Crawler status until it is completed
        while True:
            # Get the status of the crawler
            response = glue_client.get_crawler(Name=glue_crawler_name)
            crawler_status = response['Crawler']['State']
            print(f"Crawler status: {crawler_status}")
            logging.info(f"Crawler status: {crawler_status}")
            
            # Check if the crawler has finished
            if crawler_status in ['READY', 'STOPPING','STOPPED']:
                print(f"Crawler status: {crawler_status}")
                break  # The crawler has finished
            else:
                print("Crawler still running. Waiting for 60 xo")
                logging.info("Crawler still running. Waiting for 60 seconds before checking again...")
                time.sleep(60)  # Wait for 60 seconds before checking again

        # Step 3: Start DataBrew Job after Glue Crawler has completed
        logging.info(f"Starting DataBrew job: {databrew_job_name}")
        print(f"Starting DataBrew job: {databrew_job_name}")
        databrew_client.start_job_run(Name=databrew_job_name)

        # Step 4: Move files to archive after jobs are triggered
        for op in operations:
            move_files_to_archive(bucket, op['source_prefix'], op['archive_prefix'], max_files=1, timeout_buffer=timeout_buffer)

        return {
            'statusCode': 200,
            'body': json.dumps('Crawler completed, DataBrew job triggered, and files moved successfully.')
        }
        
    except Exception as e:
        logging.error(f"Error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }

def move_files_to_archive(bucket, source_prefix, archive_prefix, max_files=None, timeout_buffer=None):
    """Move files from a source directory to an archive directory in the same bucket."""
    print(f"Moving files from {source_prefix} to {archive_prefix} in bucket {bucket}")
    paginator = s3_client.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=bucket, Prefix=source_prefix)

    file_count = 0
    for page in page_iterator:
        if 'Contents' not in page:
            continue
        for file in page['Contents']:
            key = file['Key']
            if key.endswith('/'):
                continue  # Skip directories
            archive_key = f"{archive_prefix}{key.split('/')[-1]}"
            print(f"Moving {key} to {archive_key}")
            s3_client.copy_object(
                Bucket=bucket,
                CopySource={'Bucket': bucket, 'Key': key},
                Key=archive_key
            )
            s3_client.delete_object(Bucket=bucket, Key=key)
            print(f"Moved and deleted file: {key}")
            
            file_count += 1
            if max_files and file_count >= max_files:
                print(f"Moved {max_files} files. Stopping.")
                return  # Exit the function after moving 'max_files' files
