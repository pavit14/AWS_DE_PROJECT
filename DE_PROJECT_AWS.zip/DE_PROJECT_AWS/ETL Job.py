import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.functions import to_date, datediff,col, when


# Initialize the Spark and Glue context
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Define the arguments (if running from Glue console)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

# Load the main dataset (CSV) from the Glue Catalog
main_dynamic_frame = glueContext.create_dynamic_frame.from_catalog(
    database="nyc_inspection", 
    table_name="cleaned"
)

# Load the lookup dataset (JSON) from the Glue Catalog
lookup_dynamic_frame = glueContext.create_dynamic_frame.from_catalog(
    database="date-db", 
    table_name="date_json"
)

# Convert the DynamicFrames to DataFrames for easier manipulation and joining
main_df = main_dynamic_frame.toDF()
lookup_df = lookup_dynamic_frame.toDF()

print(main_df.columns)
print(lookup_df.columns)

# Perform the join operation based on a common field (e.g., "category_id")
# Assuming "category_id" is the common field for lookup
result_df = main_df.join(lookup_df, main_df['GRADE DATE'] == lookup_df['full_date'], 'left')
result_df = result_df.withColumnRenamed("day_name", "Grade Day")

print(result_df.columns)


result_df = result_df.select(
    'camis', 'dba', 'boro', 'building', 'street', 'zipcode', 
    'phone', 'cuisine description', 'inspection date', 'action', 
    'violation code', 'violation description', 'critical flag', 
    'score', 'grade', 'grade date', 'record date', 'inspection type', 
    'latitude', 'longitude', 'community board', 'council district', 
    'census tract', 'bin', 'bbl', 'nta', "Grade Day")

    
result_df = result_df.join(lookup_df, result_df['INSPECTION DATE'] == lookup_df['full_date'], 'left')
result_df = result_df.withColumnRenamed("day_name", "Inspection Day")

result_df.select('Inspection Day').show()

print(result_df.columns)

result_df = result_df.select(
    'camis', 'dba', 'boro', 'building', 'street', 'zipcode', 
    'phone', 'cuisine description', 'inspection date', 'action', 
    'violation code', 'violation description', 'critical flag', 
    'score', 'grade', 'grade date', 'record date', 'inspection type', 
    'latitude', 'longitude', 'community board', 'council district', 
    'census tract', 'bin', 'bbl', 'nta', "Grade Day","Inspection Day")
    


if 'zipcode' in result_df.columns:
    result_df = result_df.withColumn('zipcode', F.col('zipcode.long').cast('int'))
    
# Convert 'grade date' and 'inspection date' columns to DateType and calculate the difference
#result_df = result_df.withColumn('grade_date', to_date(result_df['grade date'], 'yyyy-MM-dd')).withColumn('inspection_date', to_date(result_df['inspection date'], 'yyyy-MM-dd'))

# Calculate the difference in days between grade_date and inspection_date
#result_df = result_df.withColumn('difference', datediff(result_df['grade_date'], result_df['inspection_date']))

# Optional: Cast the 'difference' column to integer type (if needed)
#result_df = result_df.withColumn('difference', result_df['difference'].cast('int'))

result_df = result_df.withColumn('grade_date', to_date(result_df['grade date'], 'yyyy-MM-dd')).withColumn('inspection_date', to_date(result_df['inspection date'], 'yyyy-MM-dd'))

# Handling null values for 'grade_date' and 'inspection_date' and calculating the difference

result_df = result_df.withColumn(
    'difference',
    when(
        col('grade_date').isNotNull() & col('inspection_date').isNotNull(), 
        datediff(col('grade_date'), col('inspection_date'))
    ).otherwise(None)
)

result_df = result_df.select(
    'camis', 'dba', 'boro', 'building', 'street', 'zipcode', 
    'phone', 'cuisine description', 'inspection date', 'action', 
    'violation code', 'violation description', 'critical flag', 
    'score', 'grade', 'grade date', 'record date', 'inspection type', 
    'latitude', 'longitude', 'community board', 'council district', 
    'census tract', 'bin', 'bbl', 'nta', "Grade Day","Inspection Day",'difference')

result_df.select('difference').show()

result_df = result_df.coalesce(1)



print(result_df.columns)

# Write the transformed data to S3 as a CSV file
output_path = "s3://de-cloud-project/transformed/"

result_df.write.mode("overwrite").csv(output_path)

print(f"Job completed successfully. The output is saved at {output_path}")
